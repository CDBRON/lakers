<template>
  <div><h1>删除订单</h1></div>
</template>

<script>
    export default {
        name: "DeleteOrder"
    }
</script>

<style scoped>

</style>
